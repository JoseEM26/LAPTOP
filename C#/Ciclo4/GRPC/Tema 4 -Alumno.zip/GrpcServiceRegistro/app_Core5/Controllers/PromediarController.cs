﻿using Microsoft.AspNetCore.Mvc;

namespace app_Core5.Controllers
{
    public class PromediarController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
