﻿using WebApplication1.Models;

namespace WebApplication1.Models
{
    public class Pais
    {
        public string CodigoPais { get; set; } = null!;
        public string NombrePais { get; set; } = null!;
    }
}